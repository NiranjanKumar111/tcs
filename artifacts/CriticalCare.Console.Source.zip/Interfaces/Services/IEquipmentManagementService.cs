using EquipmentManagementBackend.Models;
using EquipmentManagementBackend.Models.Enums;
using EquipmentManagementBackend.DTOs;

namespace EquipmentManagementBackend.Application;

public interface IEquipmentManagementService
{
    Task<long> SaveEquipmentAsync(
        Session actor,
        long? id,
        string code,
        string name,
        long type,
        long location,
        MaintenanceFrequency maintenance,
        DateOnly anchor,
        MaintenanceFrequency calibration,
        bool active = true,
        string? serialNumber = null,
        string? manufacturer = null,
        string? modelNumber = null,
        DateOnly? purchaseDate = null);
    Task DeleteEquipmentAsync(Session actor, long id);
}
