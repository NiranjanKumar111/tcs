global using EquipmentManagementBackend.Application;
global using EquipmentManagementBackend.Controllers;
