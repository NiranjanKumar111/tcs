using CriticalCare.ConsoleApp;
using EquipmentManagementBackend.DTOs;
using EquipmentManagementBackend.Models.Enums;
using static CriticalCare.ConsoleApp.ConsoleInput;

namespace EquipmentManagementBackend.Controllers;

public sealed class BackupController : MenuController
{
    private readonly IBackupsService backups;
    private readonly IReportsService reports;

    public BackupController(IAuthenticationService auth, IBackupsService backups, IReportsService reports) : base(auth)
    {
        this.backups = backups;
        this.reports = reports;
    }

    public Task RunAsync(Session session, string role) => RunMenuAsync(
        session,
        role,
        "Backup",
        new()
        {
            ["41"] = ("Request backup", () => RequestBackupAsync(session)),
            ["1"] = ("Equipment availability/filter", () => ShowEquipmentAsync(session)),
            ["2"] = ("Equipment types and locations", () => ShowReferencesAsync(session)),
            ["42"] = ("Allocation history", () => AllocationHistoryAsync(session)),
            ["43"] = ("Pickup location/deadline and details", () => ShowBackupDetailsAsync(session)),
            ["44"] = ("Retry reservation", () => RetryReservationAsync(session)),
            ["45"] = ("Mark picked up", () => MarkPickedUpAsync(session)),
            ["46"] = ("Mark returned", () => MarkReturnedAsync(session)),
            ["47"] = ("Cancel request", () => CancelRequestAsync(session)),

        });
    private async Task RequestBackupAsync(Session session)
    {
        var ward = Choice<WardType>("Ward type");
        var type = Number("Equipment type ID");
        var bed = Read("Bed number");
        BackupView.ShowBackup(await backups.RequestAsync(
                session,
                type,
                ward,
                bed,
                null));
    }

    private async Task ShowEquipmentAsync(Session session)
    {
        EquipmentListView.Show(await reports.EquipmentAsync(session, new EquipmentQuery {
                    Search = Optional("Search (blank=all)"),
                    EquipmentTypeId = OptionalId("Type ID (blank=all)"),
                    LocationId = OptionalId("Location ID (blank=all)"),
                    Page = (int)Number("Page", 1),
                    PageSize = 20
                }));
    }

    private async Task ShowReferencesAsync(Session session)
    {
        ReferenceView.Show(await reports.ReferencesAsync(session));
    }

    private async Task AllocationHistoryAsync(Session session)
    {
        BackupView.ShowList(await backups.ListAsync(session));
    }

    private async Task ShowBackupDetailsAsync(Session session)
    {
        BackupView.ShowBackup(await backups.DetailsAsync(session, Number("Request ID")));
    }

    private async Task RetryReservationAsync(Session session)
    {
        BackupView.ShowBackup(await backups.ActionAsync(session, "reserve", Number("Request ID")));
    }

    private async Task MarkPickedUpAsync(Session session)
    {
        BackupView.ShowBackup(await backups.ActionAsync(
                session,
                "pickup",
                Number("Request ID"),
                Number("Allocation ID")));
    }

    private async Task MarkReturnedAsync(Session session)
    {
        BackupView.ShowBackup(await backups.ActionAsync(
                session,
                "return",
                Number("Request ID"),
                Number("Allocation ID")));
    }

    private async Task CancelRequestAsync(Session session)
    {
        BackupView.ShowBackup(await backups.ActionAsync(session, "cancel", Number("Request ID")));
    }
}
