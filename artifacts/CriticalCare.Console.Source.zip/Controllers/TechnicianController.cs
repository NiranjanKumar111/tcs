using CriticalCare.ConsoleApp;
using EquipmentManagementBackend.DTOs;
using EquipmentManagementBackend.Models.Enums;
using static CriticalCare.ConsoleApp.ConsoleInput;

namespace EquipmentManagementBackend.Controllers;

public sealed class TechnicianController : MenuController, IRoleController
{
    private readonly IMaintenanceService maintenance;

    public TechnicianController(IAuthenticationService auth, IMaintenanceService maintenance) : base(auth)
    {
        this.maintenance = maintenance;
    }

    public string Role => "technician";

    public Task RunAsync(Session session) => RunMenuAsync(
        session,
        "technician",
        "Technician",
        new()
        {
            ["3"] = ("Ticket logs", () => TicketLogsAsync(session)),
            ["4"] = ("Ticket details/history", () => ShowTicketDetailsAsync(session)),
            ["30"] = ("Start/update assigned work", () => UpdateWorkAsync(session)),
            ["31"] = ("Record checklist", () => RecordChecklistAsync(session)),
            ["32"] = ("Record calibration measurements", () => RecordCalibrationAsync(session)),
            ["33"] = ("Submit for approval", () => SubmitForApprovalAsync(session)),
            ["34"] = ("Equipment maintenance history", () => EquipmentMaintenanceHistoryAsync(session)),

        });
    private async Task TicketLogsAsync(Session session)
    {
        TicketView.ShowTickets(await maintenance.ListAsync(session));
    }

    private async Task ShowTicketDetailsAsync(Session session)
    {
        TicketView.ShowDetails(await maintenance.DetailAsync(session, Number("Ticket ID")));
    }

    private async Task UpdateWorkAsync(Session session)
    {
        await maintenance.ProgressAsync(
            session,
            Number("Ticket ID"),
            (int)Number("Current version"),
            Read("Full work/progress report"));
    }

    private async Task RecordChecklistAsync(Session session)
    {
        await maintenance.ChecklistAsync(
            session,
            Number("Ticket ID"),
            (int)Number("Current version"),
            Read("Checklist item (same text updates it)"),
            Yes("Passed?"),
            Read("Notes"));
    }

    private async Task RecordCalibrationAsync(Session session)
    {
        await maintenance.CalibrationAsync(
            session,
            Number("Ticket ID"),
            (int)Number("Current version"),
            Read("Parameter"),
            Read("Unit"),
            Decimal("Allowed minimum"),
            Decimal("Allowed maximum"),
            Decimal("Measured value"));
    }

    private async Task SubmitForApprovalAsync(Session session)
    {
        await maintenance.SubmitAsync(
            session,
            Number("Ticket ID"),
            (int)Number("Current version"),
            Date("Work completed date"));
    }

    private async Task EquipmentMaintenanceHistoryAsync(Session session)
    {
        TicketView.ShowTickets(await maintenance.ListAsync(session, equipmentId: Number("Equipment ID")));
    }
}
