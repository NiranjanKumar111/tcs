using CriticalCare.ConsoleApp;
using EquipmentManagementBackend.DTOs;
using EquipmentManagementBackend.Models.Enums;
using static CriticalCare.ConsoleApp.ConsoleInput;

namespace EquipmentManagementBackend.Controllers;

public sealed class ApproverController : MenuController, IRoleController
{
    private readonly IMaintenanceService maintenance;

    public ApproverController(IAuthenticationService auth, IMaintenanceService maintenance) : base(auth)
    {
        this.maintenance = maintenance;
    }

    public string Role => "approver";

    public Task RunAsync(Session session) => RunMenuAsync(
        session,
        "approver",
        "Approver",
        new()
        {
            ["20"] = ("Pending approvals", () => PendingApprovalsAsync(session)),
            ["4"] = ("Ticket details/history", () => ShowTicketDetailsAsync(session)),
            ["21"] = ("Review evidence and approve/reject", () => ReviewEvidenceAndApproveRejectAsync(session)),
            ["22"] = ("Close approved ticket", () => CloseApprovedTicketAsync(session)),

        });
    private async Task PendingApprovalsAsync(Session session)
    {
        TicketView.ShowTickets(await maintenance.ListAsync(session, true));
    }

    private async Task ShowTicketDetailsAsync(Session session)
    {
        TicketView.ShowDetails(await maintenance.DetailAsync(session, Number("Ticket ID")));
    }

    private async Task ReviewEvidenceAndApproveRejectAsync(Session session)
    {
        var id = Number("Ticket ID");
        ConsoleView.ShowMessage("APPROVAL RULES: assigned independent approver; pending approval; completed work report; at least one checklist item and all checks passed; calibration measurements recorded within stated limits. Review the evidence below before deciding.");
        TicketView.ShowDetails(await maintenance.DetailAsync(session, id));
        await maintenance.ReviewAsync(
            session,
            id,
            (int)Number("Current version"),
            Yes("Approve? (n=reject)"),
            Read("Review notes"));
    }

    private async Task CloseApprovedTicketAsync(Session session)
    {
        await maintenance.CloseAsync(session, Number("Ticket ID"), (int)Number("Current version"));
    }
}
