using CriticalCare.ConsoleApp;
using EquipmentManagementBackend.DTOs;
using EquipmentManagementBackend.Models.Enums;
using static CriticalCare.ConsoleApp.ConsoleInput;

namespace EquipmentManagementBackend.Controllers;

public sealed class AdminController : MenuController, IRoleController
{
    private readonly IEmployeeService employees;
    private readonly ILocationService locations;
    private readonly IEquipmentTypeService equipmentTypes;
    private readonly IEquipmentManagementService equipmentManagement;
    private readonly IMaintenanceService maintenance;
    private readonly IReportsService reports;
    private readonly ISchedulingService scheduling;
    private readonly BackupController backupController;

    public AdminController(
        IAuthenticationService auth,
        IEmployeeService employees,
        ILocationService locations,
        IEquipmentTypeService equipmentTypes,
        IEquipmentManagementService equipmentManagement,
        IMaintenanceService maintenance,
        IReportsService reports,
        ISchedulingService scheduling,
        BackupController backupController) : base(auth)
    {
        this.employees = employees;
        this.locations = locations;
        this.equipmentTypes = equipmentTypes;
        this.equipmentManagement = equipmentManagement;
        this.maintenance = maintenance;
        this.reports = reports;
        this.scheduling = scheduling;
        this.backupController = backupController;
    }

    public string Role => "admin";

    public Task RunAsync(Session session) => RunMenuAsync(
        session,
        "admin",
        "Admin",
        new()
        {
            ["10"] = ("Equipment KPIs", () => ShowDashboardAsync(session)),
            ["11"] = ("Exceptions and escalations", () => ShowExceptionsAsync(session)),
            ["19"] = ("Audit logs", () => AuditLogsAsync(session)),
            ["3"] = ("Ticket logs", () => TicketLogsAsync(session)),
            ["4"] = ("Ticket details/history", () => ShowTicketDetailsAsync(session)),
            ["17"] = ("Create maintenance ticket", () => CreateMaintenanceTicketAsync(session)),
            ["18"] = ("Assign/reassign escalated ticket", () => AssignTicketAsync(session)),
            ["13"] = ("Employees", () => EmployeesAsync(session)),
            ["14"] = ("Add/edit employee", () => AddEditEmployeeAsync(session)),
            ["1"] = ("Equipment availability/filter", () => ShowEquipmentAsync(session)),
            ["2"] = ("Equipment types and locations", () => ShowReferencesAsync(session)),
            ["12"] = ("Add/edit equipment and frequency schedules", () => EditEquipmentAsync(session)),
            ["50"] = ("Delete equipment", () => DeleteEquipmentAsync(session)),
            ["15"] = ("Add/edit location", () => AddEditLocationAsync(session)),
            ["16"] = ("Add equipment type", () => AddEquipmentTypeAsync(session)),
            ["51"] = ("Generate due maintenance/calibration tickets", () => GenerateScheduledTicketsAsync(session)),
            ["60"] = ("Backup allocation", () => backupController.RunAsync(session, "admin")),

        });
    private async Task EquipmentAsync(Session actor)
    {
        ConsoleView.ShowMessage("Equipment uses its home location; active backup allocations prevent moving/deactivating it.");
        var id = OptionalId("Equipment ID (blank=new)");
        var code = id == null ? Read("Unique equipment code") : "";
        var saved = await equipmentManagement.SaveEquipmentAsync(
            actor,
            id,
            code,
            Read("Name"),
            Number("Equipment type ID"),
            Number("Location ID"),
            Choice<MaintenanceFrequency>("Maintenance frequency"),
            Date("Initial schedule anchor date"),
            Choice<MaintenanceFrequency>("Calibration frequency"),
            Yes("Active?"),
            Optional("Serial number (blank=keep/none)"),
            Optional("Manufacturer (blank=keep/none)"),
            Optional("Model (blank=keep/none)"));
        ConsoleView.ShowMessage("Saved equipment " + saved + ". Next dates are calculated automatically.");
    }

    private async Task EmployeeAsync(Session actor)
    {
        var id = OptionalId("Employee ID (blank=new)");
        var name = Read("Name");
        var email = Read("Email");
        var role = Read("Role: admin/approver/technician/staff").ToLowerInvariant();
        var active = Yes("Active?");
        var password = Password("New password (blank=keep existing)");
        ConsoleView.ShowMessage("Saved employee " + await employees.SaveEmployeeAsync(
                actor,
                id,
                name,
                email,
                role,
                active,
                password.Length == 0 ? null : password));
    }

    private async Task ShowDashboardAsync(Session session)
    {
        DashboardView.Show(await reports.DashboardAsync(session));
    }

    private async Task ShowExceptionsAsync(Session session)
    {
        DashboardView.Show(await reports.DashboardAsync(session, true));
    }

    private async Task AuditLogsAsync(Session session)
    {
        AuditView.Show(await reports.AuditAsync(session));
    }

    private async Task TicketLogsAsync(Session session)
    {
        TicketView.ShowTickets(await maintenance.ListAsync(session));
    }

    private async Task ShowTicketDetailsAsync(Session session)
    {
        TicketView.ShowDetails(await maintenance.DetailAsync(session, Number("Ticket ID")));
    }

    private async Task CreateMaintenanceTicketAsync(Session session)
    {
        ConsoleView.ShowMessage("Created ticket " + await maintenance.CreateAsync(
                session,
                Number("Equipment ID"),
                Choice<TicketType>("Ticket type"),
                Choice<TicketPriority>("Priority"),
                Read("Title"),
                Read("Description"),
                Date("Due date"),
                OptionalId("Technician ID (blank=automatic)"),
                OptionalId("Approver ID (blank=automatic)")));
    }

    private async Task AssignTicketAsync(Session session)
    {
        await maintenance.AssignAsync(
            session,
            Number("Ticket ID"),
            (int)Number("Current version"),
            Number("Technician ID"),
            Number("Approver ID"));
    }

    private async Task EmployeesAsync(Session session)
    {
        EmployeeView.Show(await employees.EmployeesAsync(session));
    }

    private async Task AddEditEmployeeAsync(Session session)
    {
        await EmployeeAsync(session);
    }

    private async Task ShowEquipmentAsync(Session session)
    {
        EquipmentListView.Show(await reports.EquipmentAsync(session, new EquipmentQuery {
                    Search = Optional("Search (blank=all)"),
                    EquipmentTypeId = OptionalId("Type ID (blank=all)"),
                    LocationId = OptionalId("Location ID (blank=all)"),
                    Page = (int)Number("Page", 1),
                    PageSize = 20
                }));
    }

    private async Task ShowReferencesAsync(Session session)
    {
        ReferenceView.Show(await reports.ReferencesAsync(session));
    }

    private async Task EditEquipmentAsync(Session session)
    {
        await EquipmentAsync(session);
    }

    private async Task DeleteEquipmentAsync(Session session)
    {
        await equipmentManagement.DeleteEquipmentAsync(session, Number("Equipment ID to delete (history retained)"));
        ConsoleView.ShowMessage("Equipment deleted from active inventory.");
    }

    private async Task AddEditLocationAsync(Session session)
    {
        ConsoleView.ShowMessage("Saved location " + await locations.SaveLocationAsync(
                session,
                OptionalId("Location ID (blank=new)"),
                Read("Code"),
                Read("Name"),
                Read("Building"),
                Read("Floor"),
                Choice<WardType>("Ward"),
                Optional("Room (optional)"),
                Optional("Shelf (optional)"),
                Yes("Central warehouse?")));
    }

    private async Task AddEquipmentTypeAsync(Session session)
    {
        ConsoleView.ShowMessage("Created type " + await equipmentTypes.AddTypeAsync(session, Read("Type code"), Read("Type name")));
    }

    private async Task GenerateScheduledTicketsAsync(Session session)
    {
        ConsoleView.ShowMessage("Scheduled tickets created: " + await scheduling.GenerateAsync(session));
    }
}
