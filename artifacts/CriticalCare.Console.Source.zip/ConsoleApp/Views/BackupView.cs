using EquipmentManagementBackend.Models;
using EquipmentManagementBackend.DTOs;
using EquipmentManagementBackend.Models.Enums;

namespace CriticalCare.ConsoleApp;

public static class BackupView
{
    public static void ShowBackup(BackupDetails details)
    {
        Console.WriteLine($"Request {details.Request.Id} {details.Request.Status}: {details.Request.RequestedWard} bed {details.Request.BedNumber}, server {details.ServerTimeUtc:u}");
        if (details.Reservation is { } reservation)
        {
            var location = reservation.Equipment.Location;
            Console.WriteLine($"PICKUP: {location?.Name} | Building {location?.Building} | Floor {location?.Floor} | Ward {location?.Ward} | Room {location?.Room} | Shelf {location?.Shelf}");
            Console.WriteLine($"Collect by {reservation.Allocation.ReservationExpiresAt:u} (UTC); {Math.Max(0, reservation.RemainingSeconds):F0} seconds remaining. Use Mark picked up when collected.");
        }

        foreach (var a in details.AllocationHistory)
        {
            Console.WriteLine($"Allocation {a.Allocation.Id}: equipment {a.Equipment.Id} {a.Equipment.Name}, {a.Allocation.Status}, expiry {a.Allocation.ReservationExpiresAt:u}, seconds remaining {a.RemainingSeconds:F0}");
        }

        foreach (var e in details.Escalations)
        {
            Console.WriteLine($"Escalation {e.Id}: {e.Reason}, resolved={e.ResolvedAt}");
        }
    }

    public static void ShowList(PagedResult<BackupRequest> page)
    {
        foreach (var request in page.Items)
        {
            Console.WriteLine($"{request.Id} | {request.RequestNumber} | {request.Status} | {request.RequestedWard}/{request.BedNumber} | type {request.EquipmentTypeId}");
        }
    }
}
