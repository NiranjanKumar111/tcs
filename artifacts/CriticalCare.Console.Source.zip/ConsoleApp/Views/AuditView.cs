using EquipmentManagementBackend.Models;
using EquipmentManagementBackend.DTOs;
using EquipmentManagementBackend.Models.Enums;

namespace CriticalCare.ConsoleApp;

public static class AuditView
{
    public static void Show(IReadOnlyList<AuditLog> rows)
    {
        Console.WriteLine(string.Join('\n', rows.Select(x => $"{x.Id} {x.CreatedAt:u} user={x.UserId} {x.EntityType}/{x.EntityId}: {x.Description}")));
    }
}
