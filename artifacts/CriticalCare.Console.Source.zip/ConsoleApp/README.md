# Critical Care Compliance â€” .NET 8 console application

This program connects directly to PostgreSQL. It has no controllers, HTTP client, Swagger, API server,
or dependency on the old web project's executable. Its SDK is `Microsoft.NET.Sdk`, not the Web SDK.
The original web application is preserved separately in `LegacyWeb/`. The root `Program.cs` launches this console workflow.

## Run on this computer

From the repository root:

```powershell
dotnet run --project EquipmentManagementBackend.csproj --configuration Release
```

The existing `appsettings.json` connection is copied to the console build output. Override it using
`ConnectionStrings__DefaultConnection`, or supply `-- --settings C:\path\appsettings.json`.
An environment connection override takes precedence. The app applies pending migrations on startup.
No browser opens and no HTTP port is used.

On first launch, create a NEW admin email and password (10â€“128 characters). Bootstrap is permitted
only while no account has a password hash. It cannot claim an existing email. Password input is
hidden in an interactive terminal; only salted PBKDF2 hashes are stored. Then log in.
There are no default passwords. Existing sample accounts cannot log in until an administrator
sets a password and a supported role using menu 14. The old `user` role should be changed to `staff`.

Use admin menu 14 to create at least one technician, approver, and staff account. Names/roles alone
do not log users in. Role checks run in services for every action, not just in the menu.
Inactive users lose access on the next action. Keep credentials for your administrator account.

## Roles and menus

| Role | Features |
| --- | --- |
| Admin | Dashboard (10), exceptions/compliance (11), equipment/schedules (12), employee list/edit (13/14), location details (15), equipment types (16), maintenance tickets (17), ticket reassignment (18), audit records (19), backup management (41â€“47) |
| Approver | Assigned tickets/history (3/4), pending approvals (20), approve/reject with notes (21), close an approved ticket (22), compliance dashboard (23) |
| Technician | Assigned tickets/history (3/4), work report/start/rework (30), checklist (31), calibration readings (32), submit (33), equipment maintenance history (34) |
| Staff | Availability (1), references (2), own service requests/history (3/4), raise corrective request (40), request backup (41), own allocations/history (42/43), reserve/pickup/return/cancel (44â€“47) |

Every role can view equipment and location/type reference data. Lists show IDs needed by the next
action. Ticket lists show the current VersionNumber: use it when changing a ticket. Refresh if a
concurrent user changed the version. Press 0 to log out and `exit` at the email prompt to quit.
At a failed input/action, the menu stays open. End-of-input exits instead of repeatedly prompting.

## Equipment and new schema

Location now has Building (150), Floor (100), Ward, optional Room (150) and Shelf (150).
An existing location's building/floor remain blank until edited; the migration does not invent data.
Existing wards default to OTHER. Admin menu 15 can fill them in.

Equipment has MaintenanceFrequency, MaintenanceAnchorDate, LastMaintenanceDate,
NextMaintenanceDate, and equivalent calibration fields. Frequencies are `daily`, `weekly`,
`monthly`, `quarterly`, `half_yearly`, `yearly`, and `none` for unconfigured/not scheduled.
New/changed schedules are calculated from the last approved-and-closed work completion date,
or the entered initial anchor when no verified completion exists. Monthly/yearly calculations use
calendar arithmetic: January 31 + one month becomes the last valid day in February.

Existing equipment is migrated with frequency none and null maintenance/calibration dates.
Set its schedules using menu 12. A schedule is not proof maintenance was performed: initial
schedule anchors do not populate LastMaintenanceDate. Preventive closure updates maintenance;
calibration closure updates calibration; corrective repairs do not reset preventive due dates.
Closing an older ticket cannot move an already newer verified date backwards.

An item with an open maintenance ticket is excluded from backup allocation. An allocated item
must be returned/released before a technician starts work. Descriptive edits preserve the item;
moving, deactivating, or changing the type of occupied/open-maintenance equipment is rejected.

## Complete maintenance demonstration

1. Admin: list references (2); add/edit location (15) and equipment (12). Assign frequencies and an anchor date.
2. Admin: create technician, approver and staff accounts (14). Note their IDs.
3. Admin: create a preventive ticket (17), choosing the equipment, due date, technician and approver.
   Blank assignments choose an active employee of the required role with the smallest open workload.
   If no employee exists, assignment remains empty and appears on the exception dashboard.
4. Technician: log in, list assigned tickets (3), note ID/version, start work (30).
5. Technician: add checklist evidence (31). At least one passing checklist item is required; every
   recorded check must pass. The same description updates a prior item during active work.
6. Technician: refresh the version, submit (33) with completion date from ticket creation through today (UTC).
7. Approver: list pending (20), inspect report/checklist/readings/history (4), approve or reject (21).
   Only the assigned independent approver can review. Rejection records the reason; the assigned
   technician can restart/rework (30), correct evidence and resubmit. Submitted evidence is locked.
8. Approver: close an approved ticket (22). This records closure and updates the applicable next-due date.
9. Admin/approver: view updated compliance (11/23). History and audit records remain available.

For a calibration ticket, also record parameter/unit/allowed minimum/maximum/measured result (32).
Out-of-range readings prevent submission/approval. Limits are entered with the measurement and
must be reviewed by the approver; a hospital-approved immutable template library is not implemented.
The screenshots show additional entity names but not their full definitions; the implemented evidence
tables are TicketComplianceItem, TicketCalibrationResult and TicketComplianceVerification.

Ticket transitions:

```text
open -> in_progress -> pending_approval -> approved -> completed
             ^               |
             +--- rejected <-+ (approver rejects with notes)
```

No role can jump directly from open to completed. Each mutation checks the actor, assignment,
allowed current state and latest version. Mutations/history/audit changes share a transaction.

## Backup demonstration

Stock two matching items in the central warehouse. Log in as two different staff users and request
the same preferred item (41). Each receives a different available matching item. A further request
escalates only when all matching warehouse items are occupied or unavailable for maintenance.
Staff can only view/change their own requests; admins can manage all. Menu 43 shows the equipment,
allocation ID, expiry timestamp, seconds remaining and historical allocations/escalations.

Pickup (45) sets in_use. Return (46) releases the item. Reserve (44) retries an escalated or expired
request and resolves its open escalation when successful. Cancel (47) releases an unpicked reservation.
The 20-minute deadline is persisted in PostgreSQL; the console background loop checks every 15 seconds
while you are at a menu, including during input. Actions also check expiry. When the application is
closed the loop stops, then catches up when it runs again. There is no automatic waiting-list allocation.

Allocation and maintenance mutations use the same PostgreSQL transaction advisory lock. Partial
unique indexes prevent duplicate active allocations. Each background operation uses its own DbContext.

## Dashboard definitions

Dashboard counts are fresh database queries each time you choose the menu; they are not live-pushed
while waiting for input. It shows active equipment, open tickets, pending reviews, overdue tickets,
open escalations, and separate preventive/calibration verified-current percentages.

For each percentage, denominator = active equipment with that frequency configured; numerator =
those items with a recorded verified completion and next date today or later. No configured items
means N/A, not 100%. Overdue means due date before today's UTC date. A date due today is still current.
The exception dashboard lists overdue/unverified/unconfigured maintenance, critical/overdue/unassigned
tickets and unresolved backup escalations. These are operational tracking metrics, not certification
against a particular medical or legal standard.

## Database migration and tests

Migration `20260916143310_ConsoleComplianceWorkflow` adds location fields, password hashes,
schedule fields, ticket type/work timestamps, evidence/review tables and indexes. It preserves
existing rows; no passwords or verified maintenance dates are invented for existing users/equipment.

```powershell
dotnet run --project EquipmentManagementBackend.csproj -c Release -- --migrate-only
dotnet run --project EquipmentManagementBackend.csproj -c Release -- --self-test
```

Self-tests create a randomly named isolated schema in the configured PostgreSQL database and drop
only that schema afterward. They do not bootstrap or change the real accounts. The database user
must have schema creation permission. You can use an environment override to run on a test database.
Tests cover role denial, hashed login, calendar dates, evidence, rework/approval/closure, optimistic
versions, real concurrent backup allocation, expiry, isolation between staff and audit history.

The root console project owns the migration snapshot. To generate a migration:

```powershell
dotnet ef migrations add DescriptiveChange --project EquipmentManagementBackend.csproj --configuration Release
```

The root project compiles the application. `ConsoleApp/Views/` contains console input/output. `Controllers/` coordinates menu actions,
and `Interfaces/Controllers/` contains controller contracts. Business services live in `Services/`, service/repository contracts in
`Interfaces/`, persistence adapters in `Repositories/`, and domain errors in `Infrastructure/`.
Models, DTOs, database configuration and migrations remain in their root folders.
Self-tests live in `Tests/Console/SelfTests.cs` and run with the root project's `--self-test` option.

## Files to understand

| File/folder | Responsibility |
| --- | --- |
| ../Program.cs | Configuration, startup and application composition |
| ../Controllers/ | Named menu actions calling service interfaces |
| Views/ | Console input and separate ticket, equipment, backup and dashboard views |
| ../Interfaces/Services/ | One contract per business service |
| ../Services/Authentication/AuthenticationService.cs | Login, bootstrap and role validation |
| ../Services/Administration/ | Separate employee, location, equipment-type and equipment-management services |
| ../Services/Maintenance/MaintenanceService.cs | Ticket transitions, evidence, review and closure |
| ../Services/Maintenance/SchedulingService.cs | Automatic due-ticket generation |
| ../Services/Reports/ReportsService.cs | Typed dashboard, reference, audit and equipment data |
| ../Services/Backups/BackupsService.cs | Authenticated backup request operations |
| ../Services/Inventory/ | Inventory and reservation transaction services |
| ../Repositories/ | Database factory, repository and unit of work |
| ../Models/ and ../DTOs/ | Separate entity and result files |
| ../Tests/Console/SelfTests.cs | PostgreSQL workflow verification |

See the [root architecture guide](../README.md#how-the-layers-work) for the MVC-style flow
and the interface-to-service mapping. Run the application from the root project as shown above.

Employee login is local email/password authentication. It does not implement MFA, password reset
email, or directory integration. Keep the old unauthenticated web application stopped when using
this console-based role model; its older endpoints do not enforce these new console service policies.
