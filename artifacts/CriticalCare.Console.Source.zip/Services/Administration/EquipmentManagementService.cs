using EquipmentManagementBackend.DTOs;
using EquipmentManagementBackend.Models;
using EquipmentManagementBackend.Models.Enums;
using EquipmentManagementBackend.Services;
using Microsoft.EntityFrameworkCore;

namespace EquipmentManagementBackend.Application;

public sealed class EquipmentManagementService : IEquipmentManagementService
{
    private readonly IApplicationRepository database;
    private readonly IAuthenticationService auth;

    public EquipmentManagementService(IApplicationRepository database, IAuthenticationService auth)
    {
        this.database = database;
        this.auth = auth;
    }

    public async Task<long> SaveEquipmentAsync(
        Session actor,
        long? id,
        string code,
        string name,
        long type,
        long location,
        MaintenanceFrequency maintenance,
        DateOnly anchor,
        MaintenanceFrequency calibration,
        bool active = true,
        string? serialNumber = null,
        string? manufacturer = null,
        string? modelNumber = null,
        DateOnly? purchaseDate = null)
    {
        if (!Enum.IsDefined(maintenance) || !Enum.IsDefined(calibration))
        {
            throw new ArgumentException("Invalid frequency.");
        }

        if (anchor > DateOnly.FromDateTime(DateTime.UtcNow))
        {
            throw new ArgumentException("Schedule start cannot be in the future.");
        }

        InputValidation.RequireText(name, 200, "Equipment name");
        if (serialNumber?.Length > 120 || manufacturer?.Length > 120 || modelNumber?.Length > 120)
        {
            throw new ArgumentException("Serial number, manufacturer and model must be at most 120 characters.");
        }

        await using var db = database.Open();
        await using var tx = await db.BeginInventoryAsync(default);
        await auth.RequireAsync(db, actor, "admin");
        await new BackupReservationService(db, TimeProvider.System).ExpireWithinTransactionAsync(default);
        if (!await db.EquipmentTypes.AnyAsync(x => x.Id == type && x.IsActive) || !await db.Locations.AnyAsync(x => x.Id == location && x.IsActive))
        {
            throw new ArgumentException("Choose an active equipment type and location.");
        }

        var equipment = id.HasValue ? await db.Equipment.FindAsync(id.Value) ?? throw new ArgumentException("Equipment not found.") : new Equipment();
        if (id.HasValue && (equipment.LocationId != location || equipment.EquipmentTypeId != type || !active) && (await db.BackupAllocations.AnyAsync(x => x.EquipmentId == id && (x.Status == BackupAllocationStatus.reserved || x.Status == BackupAllocationStatus.in_use)) || await db.Tickets.AnyAsync(x => x.EquipmentId == id && x.Status != TicketStatus.completed && x.Status != TicketStatus.cancelled)))
        {
            throw new ArgumentException("Occupied equipment or equipment with open maintenance cannot be moved, deactivated or change type.");
        }

        if (!id.HasValue)
        {
            InputValidation.RequireText(code, 80, "Equipment code");
            if (await db.Equipment.AnyAsync(x => x.EquipmentCode == code.Trim()))
            {
                throw new ArgumentException("Equipment code already exists.");
            }

            equipment.EquipmentCode = code.Trim();
            equipment.CreatedBy = actor.UserId;
            db.Equipment.Add(equipment);
        }

        equipment.Name = name.Trim();
        equipment.EquipmentTypeId = type;
        equipment.LocationId = location;
        equipment.IsActive = active;
        equipment.SerialNumber = serialNumber ?? equipment.SerialNumber;
        equipment.Manufacturer = manufacturer ?? equipment.Manufacturer;
        equipment.ModelNumber = modelNumber ?? equipment.ModelNumber;
        equipment.PurchaseDate = purchaseDate ?? equipment.PurchaseDate;
        equipment.UpdatedBy = actor.UserId;
        equipment.UpdatedAt = DateTime.UtcNow;
        equipment.MaintenanceFrequency = maintenance;
        equipment.MaintenanceAnchorDate = anchor;
        equipment.CalibrationFrequency = calibration;
        equipment.CalibrationAnchorDate = anchor;
        equipment.NextMaintenanceDate = Schedule.Next(equipment.LastMaintenanceDate ?? anchor, maintenance);
        equipment.NextCalibrationDate = Schedule.Next(equipment.LastCalibrationDate ?? anchor, calibration);
        await db.SaveChangesAsync();
        Database.Audit(
            db,
            actor.UserId,
            "Equipment and maintenance/calibration schedule saved",
            "Equipment",
            equipment.Id);
        await db.SaveChangesAsync();
        await tx.CommitAsync();
        return equipment.Id;
    }

    public async Task DeleteEquipmentAsync(Session actor, long id)
    {
        await using var db = database.Open();
        await using var tx = await db.BeginInventoryAsync();
        await auth.RequireAsync(db, actor, "admin");
        await new BackupReservationService(db, TimeProvider.System).ExpireWithinTransactionAsync(default);
        var equipment = await db.Equipment.FindAsync(id) ?? throw new ArgumentException("Equipment not found.");
        if (await db.BackupAllocations.AnyAsync(x => x.EquipmentId == id && (x.Status == BackupAllocationStatus.reserved || x.Status == BackupAllocationStatus.in_use)) || await db.Tickets.AnyAsync(x => x.EquipmentId == id && x.Status != TicketStatus.completed && x.Status != TicketStatus.cancelled))
        {
            throw new ArgumentException("Return reserved/in-use equipment and close maintenance tickets before deleting.");
        }

        equipment.IsActive = false;
        equipment.UpdatedBy = actor.UserId;
        equipment.UpdatedAt = DateTime.UtcNow;
        Database.Audit(
            db,
            actor.UserId,
            "Equipment soft deleted; history retained",
            "Equipment",
            id);
        await db.SaveChangesAsync();
        await tx.CommitAsync();
    }
}
